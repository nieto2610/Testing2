package com.example.parcialmaster.Tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.example.parcialmaster.Pages.BusquedaProd;
import com.example.parcialmaster.extent_reports.ExtentFactory;

public class BusquedaProdTest {

    private WebDriver driver;

    private WebDriverWait wait;

    static ExtentSparkReporter busquedaProdReporter = new ExtentSparkReporter("target/BusquedaProdReporter.html");

    static ExtentReports extent;

    String mensaje;

    @BeforeAll
    public static void crearReporte() {
        extent = ExtentFactory.getInstance();
        extent.attachReporter(busquedaProdReporter);
    }

    @BeforeEach
    public void setUp() {
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofMillis(2000));
        BusquedaProd busquedaProdPage = new BusquedaProd(driver, wait);
        busquedaProdPage.setup();
        busquedaProdPage.open("https://opencart.abstracta.us/index.php?route=common/home");
    }

    @Test
    public void AgregadoCarritoExitosoTest() {
        ExtentTest test = extent.createTest("Prueba de agregar a carrito Exitoso");
        test.log(Status.INFO, "Comienza el Test");
        BusquedaProd busquedaProdPage = new BusquedaProd(driver, wait);
        busquedaProdPage.Buscar("Iphone");
        busquedaProdPage.agregarCesta();
        mensaje = busquedaProdPage.obtenerMensajeConfirmacion();
        test.log(Status.INFO, "Inicia validacion de mensaje agregado al carrito exitoso");
        assertTrue(mensaje.contains("Success: You have added iPhone to your shopping cart!"));
        test.log(Status.PASS, "Test agregado de producto al carrito superado");
    }

    @AfterEach
    public void cerrar() {
        BusquedaProd busquedaProdPage = new BusquedaProd(driver, wait);
        busquedaProdPage.closeBrowser();
    }

    @AfterAll
    public static void reporte() {
        extent.flush();
    }
}
