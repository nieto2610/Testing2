package com.example.parcialmaster.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.example.parcialmaster.Base.BasePage;

public class RegisterPage extends BasePage {

    private By MyAccount = By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/i");
    private By Register = By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[1]/a");

    private By nombre = By.id("input-firstname");
    private By apellido = By.id("input-lastname");
    private By campoEmail = By.id("input-email");
    private By campoTelefono = By.id("input-telephone");
    private By campoClave = By.id("input-password");
    private By confirmarClave = By.id("input-confirm");
    private By noNoticias = By.xpath("//*[@id=\"content\"]/form/fieldset[3]/div/div/label[2]/input");
    private By politicasPrivacidad = By.xpath("//*[@id=\"content\"]/form/div/div/input[1]");
    private By enviarFormulario = By.xpath("//*[@id=\"content\"]/form/div/div/input[2]");
    private By mensajeConfirmacion = By.xpath("//*[@id=\"content\"]/p[1]");

    public RegisterPage(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }

    public void registrarse() {
        clickear(MyAccount);
        clickear(Register);
    }

    public void rellenarForm(String inputNombre, String inputApellido, String inputCampoEmail,
            String inputCampoTelefono, String inputCampoClave, String inputConfirmarClave) {
        sendText(inputNombre, nombre);
        sendText(inputApellido, apellido);
        sendText(inputCampoEmail, campoEmail);
        sendText(inputCampoTelefono, campoTelefono);
        sendText(inputCampoClave, campoClave);
        sendText(inputConfirmarClave, confirmarClave);
        clickear(noNoticias);
        clickear(politicasPrivacidad);
    }

    public void enviarForm() {
        clickear(enviarFormulario);
    }

    public String obtenerMensajeConfirmacion() {
        return getText(mensajeConfirmacion);
    }

}