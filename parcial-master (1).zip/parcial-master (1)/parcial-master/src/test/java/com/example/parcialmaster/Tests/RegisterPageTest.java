package com.example.parcialmaster.Tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.example.parcialmaster.Pages.RegisterPage;
import com.example.parcialmaster.extent_reports.ExtentFactory;

public class RegisterPageTest {

    private WebDriver driver;

    private WebDriverWait wait;

    static ExtentSparkReporter loginReporter = new ExtentSparkReporter("target/LoginReporter.html");

    static ExtentReports extent;

    String mensaje;

    @BeforeAll
    public static void crearReporte() {
        extent = ExtentFactory.getInstance();
        extent.attachReporter(loginReporter);
    }

    @BeforeEach
    public void setUp() {
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofMillis(2000));
        RegisterPage loginPage = new RegisterPage(driver, wait);
        loginPage.setup();
        loginPage.open("https://opencart.abstracta.us/index.php?route=common/home");
    }

    @Test
    public void RegistroExitosoTest() {
        ExtentTest test = extent.createTest("Prueba de Registro Exitoso");
        test.log(Status.INFO, "Comienza el Test");
        RegisterPage registerPage = new RegisterPage(driver, wait);
        test.log(Status.INFO, "Ingresar a la pagina de Registro");
        registerPage.registrarse();
        test.log(Status.PASS, "Dentro del registro");
        test.log(Status.INFO, "Comienza a llenar los datos");
        registerPage.rellenarForm("Carlos", "Zarete3", "carloszarete3@gmail.com", "3444517702", "123456", "123456");
        test.log(Status.PASS, "Registro exitoso");
        registerPage.enviarForm();
        mensaje = registerPage.obtenerMensajeConfirmacion();
        assertTrue(mensaje.equals("Thank you for registering with Your Store!"));
        test.log(Status.PASS, "Test registro superado");
    }

    @AfterEach
    public void cerrar() {
        RegisterPage registerPage = new RegisterPage(driver, wait);
        registerPage.closeBrowser();
    }

    @AfterAll
    public static void reporte() {
        extent.flush();
    }

}
