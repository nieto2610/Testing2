package com.example.parcialmaster.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.example.parcialmaster.Base.BasePage;

public class BusquedaProd extends BasePage {
  
    private By buscar = By.name("search");
    private By lupa = By.xpath("//*[@id=\"search\"]/span/button");
  
    private By agregarCarrito = By.xpath("//*[@id=\"content\"]/div[3]/div/div/div[2]/div[2]/button[1]");
    
    private By exito = By.xpath("//*[@id=\"product-search\"]/div[1]");
    
    public BusquedaProd(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }

    public void Buscar(String producto) {
        sendText(producto, buscar);
        clickear(lupa);
    }

    public void agregarCesta() {
        clickear(agregarCarrito);
    }

    public String obtenerMensajeConfirmacion() {
        return getText(exito);
    }

}
