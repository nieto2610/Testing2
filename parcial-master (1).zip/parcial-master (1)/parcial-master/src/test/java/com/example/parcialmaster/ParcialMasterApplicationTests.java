package com.example.parcialmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParcialMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
